#define REDIS_GIT_SHA1 "565e139a"
#define REDIS_GIT_DIRTY "0"
#define REDIS_BUILD_ID "lhl-ubuntu-1511941217"
