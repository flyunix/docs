#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

#include <hiredis.h>
#include <async.h>
#include <adapters/libevent.h>

void getCallback(redisAsyncContext *c, void *r, void *privdata) {
    (void)c;

    redisReply *reply = r;
    if (reply == NULL) return;

    //printf("argv[%s]\n", (char*)privdata);

    if(reply->elements > 0) {
        char *reply_type = reply->element[0]->str;

        /*判断接收到的消息类型*/

        /*subscribe*/
        if(strcmp(reply_type, "subscribe") == 0) {
            printf("Msg type:%s\n", reply_type);
            printf("Subcribe Channel:%s [OK]\n", reply->element[1]->str);
        }

        /*message*/
        if(strcmp(reply_type, "message") == 0) {
            printf("Msg type:%s\n", reply_type);
            printf("Subcribe Channel:%s\n", reply->element[1]->str);
            printf("Subcribe Msg Context:%s\n", reply->element[2]->str);
        }
    }
    /* Disconnect after receiving the reply to GET */
    //redisAsyncDisconnect(c);
}

void connectCallback(const redisAsyncContext *c, int status) {
    if (status != REDIS_OK) {
        printf("Error: %s\n", c->errstr);
        return;
    }
    printf("Connected...\n");
}

void disconnectCallback(const redisAsyncContext *c, int status) {
    if (status != REDIS_OK) {
        printf("Error: %s\n", c->errstr);
        return;
    }
    printf("Disconnected...\n");
}

int main (int argc, char **argv) {
    (void)argc;
    (void)argv;

    signal(SIGPIPE, SIG_IGN);
    struct event_base *base = event_base_new();

    redisAsyncContext *c = redisAsyncConnect("127.0.0.1", 6379);
    if (c->err) {
        /* Let *c leak for now... */
        printf("Error: %s\n", c->errstr);
        return 1;
    }

    redisLibeventAttach(c,base);
    redisAsyncSetConnectCallback(c,connectCallback);
    redisAsyncSetDisconnectCallback(c,disconnectCallback);
    //redisAsyncCommand(c, NULL, NULL, "SET key %b", argv[argc-1], strlen(argv[argc-1]));
    //redisAsyncCommand(c, getCallback, (char*)"end-1", "GET key");
    redisAsyncCommand(c, getCallback, (char*)"Subscribe Data:", "subscribe msg");
    event_base_dispatch(base);
    return 0;
}
